// index.js — sutramcore
'use strict';

const DbModal = require('./src/DbModal');
const BaseTable = require('./src/BaseTable');
const { setDb } = require('./src/db');
const { setSchema } = require('./src/schema-registry');
const { col, ColBuilder } = require('./src/col');
const { defineTable } = require('./src/defineTable');

// ─────────────────────────────────────────────────────────────
// ── Sutram — instance-based ORM ──────────────────────────────
// ─────────────────────────────────────────────────────────────
//
// Usage (NEW — preferred):
//   const { Sutram } = require('sutramcore');
//   const sewa = new Sutram({ db: dbmodal.db, schema: require('./schema') });
//   const myTable = sewa.table('my_table');   // returns a BaseTable instance
//   // or
//   const MyTable = sewa.BaseTable;           // access the bound class
//   const t = new MyTable('my_table');        // also works
//
// Usage (LEGACY — still works):
//   const { configure, BaseTable } = require('sutramcore');
//   configure({ db, schema });  // global singleton
//   const t = new BaseTable('my_table');

class Sutram {
    /**
     * @param {{ db, schema, dbPath?, migrations?, views? }} opts
     */
    constructor({ db = null, dbPath = null, schema, migrations = [], views = [] } = {}) {
        if (!schema) throw new Error('[sutramcore] Sutram requires schema');
        if (typeof schema !== 'object' || Array.isArray(schema)) {
            throw new Error('[sutramcore] schema must be a plain object — { tableName: { columns, joins } }');
        }

        if (db) {
            if (typeof db.prepare !== 'function') {
                throw new Error('[sutramcore] db must be a better-sqlite3 Database instance');
            }
            this.db = db;
        } else if (dbPath) {
            const modal = new DbModal(dbPath, migrations, views);
            this.db = modal.db;
        } else {
            throw new Error(
                '[sutramcore] Sutram() requires either:\n' +
                '  db     — pass your own better-sqlite3 instance\n' +
                '  dbPath — let sutramcore open and migrate the database'
            );
        }

        this.schema = schema;

        // Bind a BaseTable subclass tied to this instance's db + schema
        const self = this;
        this.BaseTable = class InstanceBaseTable extends BaseTable {
            constructor(tableName) {
                super(tableName, { db: self.db, schema: self.schema });
            }
        };

        // Clone static methods onto bound class
        this.BaseTable.transaction = (fn) => this.db.transaction(fn)();
        this.BaseTable.begin = () => this.db.prepare('BEGIN').run();
        this.BaseTable.commit = () => this.db.prepare('COMMIT').run();
        this.BaseTable.rollback = () => this.db.prepare('ROLLBACK').run();

        console.log('[sutramcore] Sutram instance ready');
    }

    /**
     * Factory — returns a BaseTable instance for `tableName`, 
     * bound to this Sutram's db + schema.
     * @param {string} tableName
     * @returns {BaseTable}
     */
    table(tableName) {
        return new this.BaseTable(tableName);
    }
}

// ─────────────────────────────────────────────────────────────
// ── Legacy singleton configure() — kept for backward compat ──
// ─────────────────────────────────────────────────────────────

let _configured = false;

function configure({ dbPath, db, schema, migrations = [], views = [] } = {}) {
    if (_configured) {
        console.warn('[sutramcore] configure() called more than once — skipping');
        return;
    }

    if (!schema) throw new Error('[sutramcore] configure() requires schema');
    if (typeof schema !== 'object' || Array.isArray(schema)) {
        throw new Error('[sutramcore] schema must be a plain object — { tableName: { columns, joins } }');
    }

    // Mode B — existing db instance (current project migration path)
    if (db) {
        if (typeof db.prepare !== 'function') {
            throw new Error('[sutramcore] db option must be a better-sqlite3 Database instance');
        }
        setDb(db);
        setSchema(schema);
        console.log('[sutramcore] Ready — using existing db instance (singleton mode)');

        // Mode A — fresh project, sutramcore manages db + migrations
    } else if (dbPath) {
        if (!Array.isArray(migrations)) {
            throw new Error('[sutramcore] migrations must be an array of arrays — [ [sql, sql], [sql] ]');
        }
        const modal = new DbModal(dbPath, migrations, views);
        setDb(modal.db);
        setSchema(schema);

    } else {
        throw new Error(
            '[sutramcore] configure() requires either:\n' +
            '  dbPath — Mode A: fresh project (sutramcore manages db + migrations)\n' +
            '  db     — Mode B: existing project (pass your own db.model instance)'
        );
    }

    _configured = true;
}

function getDb() {
    return require('./src/db').getDb();
}

// reset singleton state between tests only
function _resetForTesting() {
    _configured = false;
    require('./src/db').setDb(null);
    require('./src/schema-registry').setSchema({});
}

module.exports = { Sutram, configure, BaseTable, col, ColBuilder, defineTable, getDb, _resetForTesting };
