// src/schema-registry.js
// ─────────────────────────────────────────────────────────────
// Holds the user's tableMeta schema.
// configure() registers it once.
// BaseTable reads from it on every query build.
// ─────────────────────────────────────────────────────────────

'use strict';

let _schema = {};

function setSchema(schema) {
    if (!schema || typeof schema !== 'object') {
        throw new Error('[sutramcore] schema must be a plain object — { tableName: { columns, joins } }');
    }
    _schema = schema;
}

function getSchema() {
    return _schema;
}

function getTableMeta(tableName) {
    const meta = _schema[tableName];
    if (!meta) {
        throw new Error(
            `[sutramcore] Table "${tableName}" not found in schema.\n` +
            `Available tables: ${Object.keys(_schema).join(', ') || '(none — did you call configure?)'}`
        );
    }
    return meta;
}

module.exports = { setSchema, getSchema, getTableMeta };
