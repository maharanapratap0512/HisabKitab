// src/db.js — sutramcore
'use strict';

let _db = null;

function setDb(db) { _db = db; }

function getDb() {
    if (!_db) {
        throw new Error(
            '[sutramcore] Database not initialized.\n' +
            'Call configure({ dbPath, schema, migrations }) before using BaseTable.\n' +
            'Or for existing projects: configure({ db: dbmodal.db, schema })'
        );
    }
    return _db;
}

module.exports = { setDb, getDb };
